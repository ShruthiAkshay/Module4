package com.emp.main;

import java.util.Scanner;

import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Component;

import com.emp.bean.Employee;
import com.emp.controller.EmployeeController;


@Configuration
@EnableAutoConfiguration
@Component("com.emp")
public class TestApp {

	public static void main(String[] args) {
		ApplicationContext ctx=new ClassPathXmlApplicationContext("beans.xml");
		EmployeeController controller=(EmployeeController) ctx.getBean("employeeController");
		Employee emp=new Employee();
		emp.setEmployeeId(1001);
		emp.setEmployeeName("Akshay");
		controller.addEmployee(emp);
		System.out.println(" Employee Added Success!!!! ");
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Employee Id:");
		int employeeId=sc.nextInt();
		
		emp=controller.searchEmployee(employeeId);
		
		System.out.println(emp.getEmployeeId()+" "+emp.getEmployeeName());
		sc.close();
	}

}
