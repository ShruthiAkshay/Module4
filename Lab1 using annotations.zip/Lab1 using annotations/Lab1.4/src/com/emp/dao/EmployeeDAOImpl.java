package com.emp.dao;

import java.util.HashMap;
import java.util.Map;

import org.springframework.stereotype.Repository;

import com.emp.bean.Employee;

@Repository
public class EmployeeDAOImpl implements IEmployeeDAO {

	Map<Integer,Employee> map=new HashMap<Integer,Employee>();
	
	
	
	public Map<Integer, Employee> getMap() {
		return map;
	}



	public void setMap(Map<Integer, Employee> map) {
		this.map = map;
	}



	@Override
	public void addEmployee(Employee emp) {
		map.put(emp.getEmployeeId(), emp);
	}

	public Employee searchEmployee(int employeeId)
	{
		return  map.get(employeeId);
	}
}
