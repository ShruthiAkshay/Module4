package com.cg.lab1;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class Employee {
	@Autowired
	private SBUBean sbuBean;
	
	public SBUBean getSbuBean() {
		return sbuBean;
	}

	public void setSbuBean(SBUBean sbuBean) {
		this.sbuBean = sbuBean;
	}

	public void display()
	{
		System.out.println("SBU details:");
		System.out.println(sbuBean.getSbuId());
		System.out.println(sbuBean.getSbuName());
		System.out.println(sbuBean.getSbuHead());
	}

}
