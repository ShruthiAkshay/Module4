package com.cg.lab1;


import org.springframework.context.support.ClassPathXmlApplicationContext;


public class TestApp {

	public static void main(String[] args) {
		ClassPathXmlApplicationContext ctx= new ClassPathXmlApplicationContext("spring1.xml");
		Employee obj1 = (Employee)ctx.getBean("employee");
		obj1.display();
		ctx.close();

	}

}
