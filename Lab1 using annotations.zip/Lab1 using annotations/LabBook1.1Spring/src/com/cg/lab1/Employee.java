package com.cg.lab1;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class Employee {
	
	@Value("1001")
	private int employeeId;
	@Value("Akshay")
	private String employeeName;
	@Value("100000")
	private int employeeSalary;
	@Value("ACIS")
	private String employeeBU;
	@Value("22")
	private int employeeAge;
	public int getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}
	public String getEmployeeName() {
		return employeeName;
	}
	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}
	public int getEmployeeSalary() {
		return employeeSalary;
	}
	public void setEmployeeSalary(int employeeSalary) {
		this.employeeSalary = employeeSalary;
	}
	public String getEmployeeBU() {
		return employeeBU;
	}
	public void setEmployeeBU(String employeeBU) {
		this.employeeBU = employeeBU;
	}
	public int getEmployeeAge() {
		return employeeAge;
	}
	public void setEmployeeAge(int employeeAge) {
		this.employeeAge = employeeAge;
	}
	
	public void display()
	{
		System.out.println("Employee Details:");
		System.out.println("Employee ID: "+ employeeId);
		System.out.println("EMployee Name:"+ employeeName);
		System.out.println("Employee Salary:"+ employeeSalary);
		System.out.println("Employee BU: "+ employeeBU);
		System.out.println("Employee Age: "+ employeeAge);
		
	}
	
}
