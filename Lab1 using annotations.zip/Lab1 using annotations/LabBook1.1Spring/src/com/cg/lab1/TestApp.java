package com.cg.lab1;


import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.support.ClassPathXmlApplicationContext;


@Configuration
@EnableAutoConfiguration
@ComponentScan("com.cg.lab1")
public class TestApp {

	public static void main(String[] args) {
		ApplicationContext ctx= new ClassPathXmlApplicationContext("spring.xml");
		Employee obj1 = (Employee)ctx.getBean("employee");
		System.out.println(" Employee Added Success!!!! ");
		obj1.display();
	}

}
