package com.trainee.controller;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.trainee.bean.TraineeBean;
import com.trainee.exception.TraineeException;
import com.trainee.service.ITraineeService;

@Controller
public class TraineeController {

	@Autowired
	private ITraineeService traineeService;
	
	@RequestMapping("/showHome")
	public String showHomePage()
	{
		return("index");
	}
	
	@RequestMapping("/addTraineeForm")
	public String traineeForm()
	{
		return("addTrain");
	}
	
	@RequestMapping(value="addTrainee", method=RequestMethod.POST)
	public ModelAndView addTrain(@ModelAttribute("train") TraineeBean bean,
			BindingResult result)
	{
		ModelAndView mv = new ModelAndView();
		
		if(result.hasErrors())
		{
			mv.setViewName("error");
			mv.addObject("message", "Binding Failed");
		}
		else
		{
			try {
				int id = traineeService.addTrainee(bean);
				mv.setViewName("success");
				mv.addObject("id", id);
				mv.addObject("train", bean);
			} catch (TraineeException e) {
				mv.setViewName("error");
				mv.addObject("message", e.getMessage());
			}
		}
		
		return mv;
	}
	
	@RequestMapping("deleteTrainee")
	public String deletetraineeForm()
	{
		return("deleteTrain");
	}
	
	@RequestMapping(value="getDetail",method=RequestMethod.POST)
	public ModelAndView getDetail(@ModelAttribute("trainee") TraineeBean bean, @RequestParam("traineeId") int traineeId) throws Exception{
		
		ModelAndView mv = new ModelAndView();
		try {
			bean = traineeService.search(traineeId);
			System.out.println("in search: "+bean);
			mv.addObject("trainee", bean);
			mv.addObject("message", "Deleted");
			mv.setViewName("deleteTrain");
		} catch (Exception e) {
			mv.addObject("message", e.getMessage());
			mv.setViewName("error");
		}
		
		return mv;
	}
	

	@RequestMapping(value="deleteDetail",method=RequestMethod.POST)
	public ModelAndView deleteDetail(@ModelAttribute("trainee") TraineeBean bean,@RequestParam("traineeId") int traineeId) throws Exception{
		
		ModelAndView mv = new ModelAndView();
		
		try {
			bean = traineeService.deleteTrainee(traineeId);
			System.out.println("in delete: "+bean);
			mv.addObject("message", "Record deleted");
			mv.addObject("trainee", bean);
			mv.setViewName("deleteSuccess");
		} catch (Exception e) {
			mv.addObject("message", e.getMessage());
			mv.setViewName("error");
		}
		
		return mv;
	}
		
	@RequestMapping("modifyTrainee")
	public String modifyTraineeForm()
	{
		System.out.println("Inside Modify");
		return("modifyTrain");
	}
	
	@RequestMapping(value="getModify",method=RequestMethod.POST)
	public ModelAndView getModifyForm(@ModelAttribute("trainee") TraineeBean bean, @RequestParam("traineeId") int traineeId) throws Exception{
		
		ModelAndView mv = new ModelAndView();
		try {
			bean = traineeService.search(traineeId);
			System.out.println("in get: "+bean);
			mv.addObject("trainee", bean);
			mv.addObject("message", "Modified");
			mv.setViewName("modifyTrain");
		} catch (Exception e) {
			mv.addObject("message", e.getMessage());
			mv.setViewName("error");
		}
		
		return mv;
	}
	
	@RequestMapping(value="changeDetail",method=RequestMethod.POST)
	public ModelAndView changeDetail(@ModelAttribute("trainee") TraineeBean bean) throws Exception{
		
		ModelAndView mv = new ModelAndView();
		boolean isUpdated = false;
		try {
			System.out.println("in update");
			isUpdated = traineeService.updateTrainee(bean);
			System.out.println("in update: "+isUpdated);
			mv.addObject("message", "Record updated");
			mv.addObject("trainee", bean);
			mv.setViewName("modifySuccess");
		} catch (Exception e) {
			mv.addObject("message", e.getMessage());
			mv.setViewName("error");
		}
		
		return mv;
	}
	
	@RequestMapping("viewTrainee")
	public String getTraineeForm()
	{
		System.out.println("Inside retrieve");
		return("viewTrain");
	}
	
	@RequestMapping(value="GetTrainee",method=RequestMethod.POST)
	public ModelAndView getTrainee(@ModelAttribute("trainee") TraineeBean bean) throws Exception{
		
		ModelAndView mv = new ModelAndView();
		try {
			bean = traineeService.search(bean.getTraineeId());
			System.out.println("in retrieve: "+bean);
			mv.addObject("trainee", bean);
			mv.addObject("message", "Retrieved");
			mv.setViewName("viewTrain");
		} catch (Exception e) {
			mv.addObject("message", e.getMessage());
			mv.setViewName("error");
		}
		
		return mv;
	}
	
	@RequestMapping("viewAllTrainee")
	public ModelAndView showAllTrainees(@ModelAttribute("trainee") TraineeBean bean)
	{
		ModelAndView mv = new ModelAndView();
		try {
			List<TraineeBean> list = traineeService.viewAllTrainee();
			mv.setViewName("viewAll");
			mv.addObject("list" ,list);
		} catch (TraineeException e) {
			mv.setViewName("error");
			mv.addObject("message",e.getMessage());
		}
		return mv;
	}
	
}
