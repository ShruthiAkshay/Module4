package com.emp.main;

import java.util.ArrayList;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.emp.bean.Employee;
import com.emp.bean.EmployeeList;




public class TestApp {

	public static void main(String[] args) {
		ApplicationContext ctx=new ClassPathXmlApplicationContext("beans.xml");
		Employee e=(Employee)ctx.getBean("employee");
		
		System.out.println(e.getEmployeeId());
		System.out.println(e.getEmployeeName());
		
		EmployeeList eL=(EmployeeList)ctx.getBean("employees");
		ArrayList<Employee> eList=eL.getEmployeeList(); 
		
		for(Employee emp: eList)
		{
			System.out.println(emp.getEmployeeId()+" "+emp.getEmployeeName());
		}
	}

}
