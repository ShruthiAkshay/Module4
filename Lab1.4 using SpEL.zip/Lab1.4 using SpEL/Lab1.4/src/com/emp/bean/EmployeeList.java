package com.emp.bean;

import java.util.ArrayList;

public class EmployeeList {
	private ArrayList<Employee> employeeList;

	public ArrayList<Employee> getEmployeeList() {
		return employeeList;
	}

	public void setEmployeeList(ArrayList<Employee> employeeList) {
		this.employeeList = employeeList;
	}
	
}
