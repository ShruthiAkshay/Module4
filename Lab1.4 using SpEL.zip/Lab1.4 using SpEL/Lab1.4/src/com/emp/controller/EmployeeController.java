package com.emp.controller;

import com.emp.bean.Employee;
import com.emp.service.IEmployeeService;

public class EmployeeController {

	IEmployeeService employeeService;
	
	
	
	public IEmployeeService getEmployeeService() {
		return employeeService;
	}



	public void setEmployeeService(IEmployeeService employeeService) {
		this.employeeService = employeeService;
	}



	public void addEmployee(Employee emp)
	{
		employeeService.addEmployee(emp);
	}
	
	public Employee searchEmployee(int employeeId)
	{
		return  employeeService.searchEmployee(employeeId);
	}
}
