package com.trainee.service;

import java.util.List;

import com.trainee.bean.TraineeBean;
import com.trainee.exception.TraineeException;

public interface ITraineeService {

	public int addTrainee(TraineeBean bean) throws TraineeException;

	public TraineeBean deleteTrainee(int traineeId) throws TraineeException;

	public TraineeBean displayTrainee(int traineeId) throws TraineeException;

	public TraineeBean modifyTrainee(int traineeId, String traineeName,
			String traineeDomain, String traineeLocation)
			throws TraineeException;
	
	public List<TraineeBean> retrieveAllTrainees()throws TraineeException;
}
