package com.trainee.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.trainee.bean.TraineeBean;
import com.trainee.dao.ITraineeDao;
import com.trainee.exception.TraineeException;

@Service
public class TraineeSerivceImpl implements ITraineeService {

	@Autowired
	private ITraineeDao traineeDao;

	@Override
	public int addTrainee(TraineeBean bean) throws TraineeException {

		return traineeDao.addTrainee(bean);
	}

	@Override
	public TraineeBean deleteTrainee(int traineeId) throws TraineeException {

		return traineeDao.deleteTrainee(traineeId);
	}

	@Override
	public TraineeBean displayTrainee(int traineeId) throws TraineeException {

		return traineeDao.displayTrainee(traineeId);
	}

	@Override
	public TraineeBean modifyTrainee(int traineeId, String traineeName,
			String traineeDomain, String traineeLocation)
			throws TraineeException {

		return traineeDao.modifyTrainee(traineeId, traineeName, traineeDomain,
				traineeLocation);
	}

	@Override
	public List<TraineeBean> retrieveAllTrainees() throws TraineeException {
		
		return traineeDao.retrieveAllTrainees();
	}

}
