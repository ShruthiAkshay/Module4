package com.trainee.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.trainee.bean.TraineeBean;
import com.trainee.exception.TraineeException;
import com.trainee.service.ITraineeService;

@Controller
public class TraineeController {

	@Autowired
	private ITraineeService traineeService;

	@RequestMapping("/showHome")
	public String showHomePage() {
		return ("index");
	}

	@RequestMapping("/addTraineeForm")
	public String traineeForm(Model model) {
		TraineeBean   bean=new TraineeBean();
		model.addAttribute("train",bean);
		return ("addTra");
	}

	@RequestMapping(value = "addTrainee", method = RequestMethod.POST)
	public ModelAndView addTrain(@ModelAttribute("train") @Valid TraineeBean bean,
			BindingResult result) {
		ModelAndView mv = new ModelAndView();

		if (result.hasErrors()) {
			mv.setViewName("addTra");
			mv.addObject("message", "Binding Failed");
		} else {
			try {
				int id = traineeService.addTrainee(bean);
				mv.setViewName("success");
				mv.addObject("id", id);
				mv.addObject("train", bean);
			} catch (TraineeException e) {
				mv.setViewName("error");
				mv.addObject("message", e.getMessage());
			}
		}

		return mv;
	}

	@RequestMapping("/deleteTraineeForm")
	public String traineeDeleteForm() {
		return ("deleteForm");
	}

	@RequestMapping(value = "/delete", method = RequestMethod.POST)
	public ModelAndView delete(@ModelAttribute("train") TraineeBean bean) {

		ModelAndView mv = new ModelAndView();
		try {
			TraineeBean tbean = traineeService.displayTrainee(bean
					.getTraineeId());

			mv.setViewName("deleteForm");
			mv.addObject("train", tbean);
		} catch (TraineeException e) {
			mv.setViewName("error");
			mv.addObject("message", e.getMessage());
		}

		return (mv);
	}

	@RequestMapping(value = "/deleteTrainee", method = RequestMethod.POST)
	public ModelAndView deleteTrainee(
			@ModelAttribute("train") TraineeBean bean, BindingResult result) {
		ModelAndView mv = new ModelAndView();
		System.out.println(" in controller " + bean.getTraineeId());
		if (result.hasErrors()) {
			mv.setViewName("error");
			mv.addObject("message", "Binding Failed");
		} else {
			try {
				TraineeBean tbean = traineeService.deleteTrainee(bean
						.getTraineeId());

				mv.setViewName("deleteSuccess");
				mv.addObject("tbean", tbean);

			} catch (TraineeException e) {
				mv.setViewName("error");
				mv.addObject("message", e.getMessage());
			}

		}

		return (mv);
	}

	@RequestMapping("/modifyTraineeForm")
	public String modifyForm() {
		return ("modifyForm");
	}

	@RequestMapping(value = "/modify", method = RequestMethod.POST)
	public ModelAndView modify(@ModelAttribute("train") TraineeBean bean) {

		ModelAndView mv = new ModelAndView();
		try {
			TraineeBean tbean = traineeService.displayTrainee(bean.getTraineeId());

			mv.setViewName("modifyForm");
			mv.addObject("train", tbean);
		} catch (TraineeException e) {
			mv.setViewName("error");
			mv.addObject("message", e.getMessage());
		}

		return (mv);
	}

	@RequestMapping(value = "/updateTrainee", method = RequestMethod.POST)
	public ModelAndView updateTrainee(@ModelAttribute("train") TraineeBean bean) {
		ModelAndView mv = new ModelAndView();

		
		try {
			TraineeBean tbean = traineeService.modifyTrainee(bean.getTraineeId(),
					bean.getTraineeName(), bean.getTraineeDomain(),
					bean.getTraineeLocation());

			mv.setViewName("updateSuccess");
			mv.addObject("train", tbean);
		} catch (TraineeException e) {
			mv.setViewName("error");
			mv.addObject("message", e.getMessage());
		}
		
		return (mv);
	}
	
	@RequestMapping("/retrieveTraineeForm")
	public String retrieveForm()
	{
		return("retrieveForm");
	}
	
	@RequestMapping(value="/retrieveTrainee", method=RequestMethod.POST)
	public ModelAndView retrieveTrainee(@ModelAttribute("train") TraineeBean bean)
	{
		ModelAndView mv = new ModelAndView();
		
		try {
			TraineeBean tbean = traineeService.displayTrainee(bean.getTraineeId());

			mv.setViewName("retrieveForm");
			mv.addObject("train", tbean);
		} catch (TraineeException e) {
			mv.setViewName("error");
			mv.addObject("message", e.getMessage());
		}
		
		return (mv);
	}
	
	@RequestMapping("/retrie")
	public String retrieveAllForm()
	{
		return("retrieveAllForm");
	}
	
	@RequestMapping("/retrieveAllTraineeForm")
	public ModelAndView retrieveAllTrainee(@ModelAttribute("train") TraineeBean bean)
	{
		ModelAndView mv = new ModelAndView();
		try {
			List<TraineeBean> list= traineeService.retrieveAllTrainees();
			mv.setViewName("retrieveShowAll");
			mv.addObject("list", list);
		} catch (TraineeException e) {
			mv.setViewName("error");
			mv.addObject("message", e.getMessage());
		}
		
		
		return (mv);
	}
	
}
